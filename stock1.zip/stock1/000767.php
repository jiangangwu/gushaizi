
<?php
$host='rds48z5k409g0753v62j.mysql.rds.aliyuncs.com';
$user='r0gbqnbc4x';
$password='19760209';
$db='r0gbqnbc4x';
$connect=mysql_connect($host,$user,$password);
mysql_select_db($db);
mysql_query("set names 'utf8'");
$ip=getenv('REMOTE_ADDR');

$page='000767';

$name=@$_GET['name'];
$name1=@$_COOKIE['name'];
if ($name=='') {$name=$name1;}
echo '<html lang="zh-CN"> <meta charset="utf-8" http-equiv="Content-Type" content="text/html;"><title>漳泽电力</title><head><link rel="shortcut icon" href="/favicon.ico">';
echo '<link rel="apple-touch-icon" href="/custom_icon.png"><style type="text/css">  table {align:center;center:float;display:inline;}  a:link {color:RoyalBlue;text-decoration:none;}  a:hover {color:#FFA500;}  a:active {color:#FF0000;} </style> </head>';
echo '<body align="center" bgcolor="#FFFFF4">';
if ($name!=""){
    echo '<table width="100%" boder="0"><tr><td></td><td align="right" style="line-height:1;"><a target="_blank" style="color:#A1A1A1;" href="/stock1/user_homepage.php"><small>欢迎您！</small>';
    echo $name1;
}else{
        echo '<table width="100%" boder="0"><tr><td></td><td align="right" style="line-height:1;"><a target="_blank" style="color:#A1A1A1;"><small>欢迎您！</small>';
}
echo '</a></td></tr></table>';
echo '<blockquote><blockquote>';
?>
<div style = "line-height:0.35"><br/></div><h2  align="center"><a href="http://www.zhangzepower.com" target="_blank">漳泽电力（000767）</a></h2><small><br/><a style="color:#A1A1A1;" href="#liuyan">留言</a><br/></small><?php $code="000767";
            $sql_stock="select code from stock where name='$name1' and code='$code' limit 1;";

            $result_stock=mysql_query($sql_stock);
            $arr_stock=mysql_fetch_array($result_stock);

            if ($arr_stock[0]=='' and $name1!=''){
            	echo "<form method='POST' name='form1' action=''><p align='center'><input type='submit' style='width:60px;color:#A1A1A1;background:white;border:0' value='加入自选' name='regard1' id='regard1'/></p></form>";
            }
            if ($arr_stock[0]!='' and $name1!=''){
            	echo "<form method='POST' name='form1' action=''><p align='center'><input type='submit' style='width:60px;color:#A1A1A1;background:white;border:0' value='取消自选' name='regard1' id='regard1'/></p></form>";
            }
            $regard = @$_POST['regard1'];
            if ($regard=="取消自选"){
            	$sql="DELETE FROM stock WHERE code='$code' and name='$name1';";
            	$result=mysql_query($sql);
            	if ($result){
            		echo '<meta charset="utf-8" http-equiv="Content-Type" content="text/html;">';
            		echo "<script>form1.regard1.value='加入自选';</script>";
            	}else{
            		echo '<meta charset="utf-8" http-equiv="Content-Type" content="text/html;">';
            		echo "<script>alert('取消自选失败，请重试。');</script>";
            	}
            }

        $stockname="漳泽电力";
     if ($regard=="加入自选"){
            	$sql="INSERT INTO stock (id, name, code, sign, time_at, stockname) VALUES (NULL, '$name1', '$code', '1', NOW(), '$stockname');";
            	$result=mysql_query($sql);
            	if ($result){
            		echo '<meta charset="utf-8" http-equiv="Content-Type" content="text/html;">';
            		echo "<script>form1.regard1.value='取消自选';</script>";
            	}else{
            		echo '<meta charset="utf-8" http-equiv="Content-Type" content="text/html;">';
            		echo "<script>alert('加入自选失败，请重试。');</script>";
            	}
            }
    ?>
    <p align="center">2016-04-25&nbsp;&nbsp;当天涨跌幅：0.5%</p><p align = "center"><a href="http://guba.eastmoney.com/list,000767,5.html" target="_blank">东方财富</a><a href="http://finance.sina.com.cn/realstock/company/sz000767/nc.shtml" target="_blank">&nbsp;&nbsp;新浪</a><a href="http://www.windin.com/home/stock/html/000767.SZ.shtml" target="_blank">&nbsp;&nbsp;万得</a><a href="http://xueqiu.com/S/SZ000767" target="_blank">&nbsp;&nbsp;雪球</a><a href="http://www.cninfo.com.cn/information/companyinfo_n.html?fulltext?szcn000767" target="_blank">&nbsp;&nbsp;巨潮公告</a></p><h4 align="center"><h4 align="center">（一）基本判断  </h4><p align="center"><b>建议买入</b></p><p align="center"><table cellspacing="0"  align="center" border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>股票排序</td><td>97</td><td>预计上涨</td><td><font color="Chocolate">15.4%</font></td></tr><tr><td>收盘价</td><td>4.26</td><td>合理价</td><td>4.9</font></td></tr><tr><td>行业得分</td><td>0.77</td><td>股票得分</td><td>0.41</font></td></tr><tr><td>安全系数</td><td>0.8</td><td>主观评分</td><td>0.8</td></tr><tr><td>52周最低</td><td>4.1</td><td>52周最高</td><td>12.0</td></tr><tr><td>建议买入价</td><td>2.5</td><td>建议卖出价</td><td>4.2</td></tr><tr><td><b>估计成长率</b></td><td><b>21.1%</b></td><td><b>历史成长率</b></td><td><b>82.8%</b></td></tr><tr><td>市场泡沫</td><td></b>29.2%</td><td>上证A股</td><td>14.7%</td></tr><tr><td>中小板</td><td>35.4%</td><td>创业板</td><td>37.6%</td></tr><tr><td>行业泡沫</td><td>-0.4%</td></b><td>行业平均得分</td><td>0.77</td></tr><tr><td style="word-wrap:break-word;"><a href="/stock1/gysy1.php">1. 公用事业</a></td><td>4.7%</td><td style="word-wrap:break-word;"><a href="/stock1/gysye2.php">2. 公用事业Ⅱ</a></td><td>4.7%</td></tr><tr><td style="word-wrap:break-word;"><a href="/stock1/dls3.php">3. 电力Ⅲ</a></td><td>-5.5%</td><td style="word-wrap:break-word;"><a href="/stock1/dl4.php">4. 电力</a></td><td>-5.5%</td></tr></table><h4 align="center">（二）股票现值情况</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>TTM市盈率</td><td>11.7</td><td>上年利润市盈率</td><td>17.4</td></tr><tr><td>TTM收益</td><td>0.4</td><td>股价收益率</td><td>5.7%</td></tr><tr><td>第三季度市净率</td><td>2.1</td><td>第三季负债率</td><td>79.1%</td></tr><tr><td>股票流通市值</td><td>67亿</td><td>总市值</td><td>96亿</td></tr><tr><td>流通股数</td><td>15.7亿</td><td>总股数</td><td>22.5亿</td></tr><tr><td>周收益</td><td>-7.6%</td><td>月收益</td><td>-7.2%</td></tr><tr><td>近一年收益</td><td>-41.2%</td><td>两年复利</td><td>32.8%</td></tr><tr><td>五年年复利</td><td>8.3%</td><td>溢折价率</td><td>-13.3%</td></tr></table><h4 align="center">（三）估计合理价格：4.9</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>合理市盈率</td><td>13.5</td><td>股票估计上涨率</td><td><font color="Chocolate">15.4%</font></td></tr><tr><td>加权估价</td><td>5.6</td><td>扣非TTM估价（占3/6）</td><td>8.4</td></tr><tr><td>平均收益估价（占2/6）</td><td>3.2</td><td>TTM估价（占1/6）</td><td>10.5</td></tr><tr><td>收益估计成长率</td><td>21.1%</td><td>收益历史成长率</td><td>82.8%</td></tr></table><h4 align="center">（四）股票弹性得分：0.62</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>偏离20日均价</td><td>-6.7%</td><td>偏离60日均价</td><td>-5.8%</td></tr><tr><td>MACD</td><td>-0.1</td><td>六月一十五到大盘最底部跌幅</td><td>-41.4%</td></tr><tr><td>两年波动率</td><td>63.8%</td><td>五年波动率</td><td>46.2%</td></tr><tr><td>两年贝他</td><td>1.6</td><td>五年贝他</td><td>1.4</td></tr><tr><td>主营占比</td><td>86.61%</td><td>员工人数</td><td>8232</td></tr><tr><td>流通股数</td><td>16亿股</td><td>总股数</td><td>23亿股</td></tr><tr><td>户均股数季增加率</td><td>3.6%</td><td>户均股数半年增加率</td><td>-42.4%</td></tr><tr><td>研发占与总资产比</td><td>0.0%</td><td>固定资产与总资产比</td><td>53.6%</td></tr><tr><td>当年热度趋势</td><td>-37.1%</td><td>当月热度趋势</td><td>16.0%</td></tr></table><h4 align="center">（五）利润成长能力得分：0.79</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>利润加权成长率</td><td>82.8%</td><td>利润趋势</td><td>-60.0%</td></tr><tr><td>15年预告增长</td><td><font color="Chocolate">0.0%</font></td><td>前三季增长率</td><td>34.6%</td</tr><tr><td>近三年增长率</td><td>100.3%</font></td><td>上半年增长率</td><td>120.2%</td</tr><tr><td>去年增长率</td><td>20.9%</td><td>三季度每股收益</td><td>0.1元</td></tr></table><h4 align="center">（六）主营成长得分：0.46</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>主营加权成长率</td><td>0.9%</td><td>主营增长趋势</td><td>86.8%</td></tr><tr><td>主营三季增长率</td><td>-30.8%</td><td>近半年增长率</td><td>-12.8%</td></tr><tr><td>近三年增长率</td><td>41.7%</td><td>去年增长率</td><td>19.4%</td></tr><tr><td>前年增长率</td><td>85.3%</td><td>三季度主营</td><td>23.4亿</td></tr></table><h4 align="center">（七）盈利能力得分：0.75</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>毛利加权成长率</td><td>63.5%</td><td>毛利趋势</td><td>-23.7%</td></tr><tr><td>第三季毛利率</td><td>24.2%</td><td>第三季毛利增长率</td><td>33.3%</td></tr><tr><td>半年毛利率</td><td>24.3</td><td>半年毛利增长率</td><td>32.4%</td></tr><tr><td>市销率TTM</td><td>1.6</td><td>股价收益率</td><td>5.7%</td></tr><tr><td>去年净资产收益率</td><td>11.2%</td><td>三季净资产收益率</td><td>10.8%</td></tr></table><br/><h4 align="center">（八）稳健性得分：0.31</h4><p align="center"><table cellspacing="0"  border="1" bordercolor="#D0D0D0" cellpadding="4"><tr><td>近三年股息收益率</td><td>0.0%</td><td>现金TTM与股价比</td><td>0.9%</td></tr><tr><td>8月25日涨跌幅</td><td>-9.9%</td><td>第三季负债率</td><td>79.1%</td></tr><tr><td>14年3季销售费用占销售比</td><td>0.0%</td><td>15年3季销售费用占销售比</td><td>0.0%</td></tr><tr><td>14年3季管理费用占销售比</td><td>1.0%</td><td>15年3季管理费用占销售比</td><td>1.2%</td></tr><tr><td>大股东持股占比</td><td>30.2%</td><td>前十大股东持股占比</td><td>60.3%</td></tr></table><h4 align="center">（九）安全性得分：0.8</h4><p align="center">(近三年30个避免陷阱数：23&nbsp;&nbsp;近一年12个避免陷阱数：10)<p align="center"><table width="70%" cellspacing="0"  border="1" bordercolor="#D0D0D0" style="font-size 12px;center:float;display:inline;word-wrap:break-word;" cellpadding="4"><tr height="50px"><td>日期</td><td>其他应收款比总资产</td><td><10%</td><td>其它经营现金比经营现金</td><td><10%</td><td>其它投资现金比投资现金<td><10%</td><td>营业外收入比营收<td><10%</td><td>经营活动现金<td>>0</td><td>总资产收益率</td><td>>7%</td></tr><tr><td align="center">2011</td><td align="center">0.2%</td><td align="center">1</td><td align="center">2.8%</td><td align="center">1</td><td align="center">1.1%</td><td align="center">1</td><td align="center">0.3%</td><td align="center">1</td><td align="center">-1</td><td align="center">0</td><td align="center">-6.5%</td><td align="center">0</td></tr><tr><td align="center">2012</td><td align="center">0.8%</td><td align="center">1</td><td align="center">0.7%</td><td align="center">1</td><td align="center">17.0%</td><td align="center">0</td><td align="center">9.2%</td><td align="center">1</td><td align="center">4</td><td align="center">1</td><td align="center">0.3%</td><td align="center">0</td></tr><tr><td align="center">2013</td><td align="center">9.9%</td><td align="center">1</td><td align="center">1.8%</td><td align="center">1</td><td align="center">0.3%</td><td align="center">1</td><td align="center">1.3%</td><td align="center">1</td><td align="center">22</td><td align="center">1</td><td align="center">2.8%</td><td align="center">0</td></tr><tr><td align="center">2014</td><td align="center">1.8%</td><td align="center">1</td><td align="center">1.2%</td><td align="center">1</td><td align="center">0.1%</td><td align="center">1</td><td align="center">2.0%</td><td align="center">1</td><td align="center">28</td><td align="center">1</td><td align="center">2.2%</td><td align="center">0</td></tr><tr><td align="center">1509</td><td align="center">2.6%</td><td align="center">1</td><td align="center">1.7%</td><td align="center">1</td><td align="center">2.0%</td><td align="center">1</td><td align="center">1.8%</td><td align="center">1</td><td align="center">14.7</td><td align="center">1</td><td align="center">2.3%</td><td align="center">0</td></tr></table> </p><h4 align="center">（十）股票概况</h4><p align="center"><table width="70%" cellspacing="0"  border="1" bordercolor="#D0D0D0" style="font-size 12px;center:float;display:inline;" cellpadding="4"><tr><td>IPO</td><td>1997-06-09</td></tr><tr><td>属性</td><td>地方国有企业</td></tr><tr><td>省市</td><td>山西省&nbsp;太原市</td></tr><tr><td nowrap="nowrap">行业</td><td>公用事业->公用事业Ⅱ->电力Ⅲ->电力<tr><td>品类</td><td>超硬材料、电解铝、火电、热力</td></tr><tr><td>品名</td><td>漳泽电力电解铝、漳泽电力山西省火电供应、漳泽电力炭素、漳泽电力蒸汽和热水供应</td></tr><tr><td>板块</td><td>CDM项目;大盘蓝筹</td></tr><tr><td>简介</td><td>公司总部位于山西太原，主营火力发电生产公司，拥有两座大型火力发电厂和一家电力检修公司，公司下设三个分公司、一个子公司和五个参股公司，在中国企业信用评级中被评为AAA级业，是山西电网和华北电网的主力发电企业，公司目前已有、在建和拟建项目主要服务山西南网区域。华泽铝电是公司与中国铝业合资成立的国内最大的铝电联营项目，被誉为世界"铝电联营"的典范，拥有较强的竞争力。先后获得“全国五一劳动奖状”、“全国模范之家”、“中央企业思想政治工作先进单位”、“中国上市公司百强企业”等荣誉称号。</td></tr><tr><td>评价</td><td>打折：0.8。评价：转型行业。</td></tr></table></p><table><br/></table>
<?php
if ($name!=""){
	$result=mysql_query("select * from bbs where page='$page' order by time_at desc;");
	$result2=mysql_query("select count(*) from bbs where page='$page';");
	$arr2=mysql_fetch_array($result2);
	echo "<p style='color:#9D9D9D;'>共";
	echo $arr2[0];
	echo "条。</p>";
     while ($arr=mysql_fetch_array($result)){
		echo '<table border="0" width="70%" id="table1" bgcolor="#FFFFF4"><tr><td>';
		echo "<a style='color:#000093;' href='/stock1/user.php?name=";
           echo $arr[1];
           echo "'>";
		echo $arr[1];
		echo '</a><font style="color:#9D9D9D;">（';
		echo $arr[4];
		echo '）：</font><h3 align="center">';
            echo "<a target='_blank' href='/stock1/comment.php?id=$arr[0]'>";
           echo $arr[6];
           echo "</a></h3>";
           if (strlen($arr[2])>3500){
               echo substr($arr[2],0,3500);
               echo "<br/>&nbsp&nbsp...... ......";
            }else{
                echo $arr[2];
            }
		echo "</td></tr><tr><td align='center'><p align='center'><a target='_blank' style='color:#9D9D9D;' href='/stock1/comment.php?id=$arr[0]'>";
           $result3=mysql_query("select count(*) from comment where id0='$arr[0]';");
           $arr3=mysql_fetch_array($result3);
           echo "<br/><br/>看全文及评论（共";
           echo $arr3[0];
           echo "条评论）</a>&nbsp&nbsp";
           echo '</td></tr></table><br/>';
		if ($name === $arr[1] and $name!='Jiangang'){
			echo
"<a onclick= 'if(confirm(\"是否确定删除！\")==false)return false;' style='font-size:9pt;color:#A1A1A1;' target='_blank' href='/stock1/del.php?id=$arr[0]'>[删除]</a>";
			echo "&nbsp&nbsp<a style='font-size:9pt;color:#A1A1A1;' target='_blank' href='/stock1/modify.php?id=$arr[0]'>[修改]</a></p><br/><br/>";
		}
		 if ($name === 'Jiangang'){
			echo
"<a onclick= 'if(confirm(\"是否确定删除！\")==false)return false;' style='font-size:9pt;color:#A1A1A1;' target='_blank' href='/stock1/del.php?id=$arr[0]'>[删除]</a>";
			echo "&nbsp&nbsp<a style='font-size:9pt; color:#A1A1A1;' target='_blank' href='/stock1/modify.php?id=$arr[0]'>[修改]</a></p><br/><br/>";
		}

	}
	$result1=mysql_query("SELECT gender FROM user WHERE name='$name';");
	$arr1=mysql_fetch_array($result1);
	if ($arr1[0]==1)	$gender='先生';else if ($arr[0]==2)	$gender='女士';else	$gender='';
	echo "<font color='#8E8E8E'><p>";
	echo $name;
	echo $gender;
	echo '&nbsp';
      echo '请留言：&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</font>';
      echo '<form method="POST" action="/stock1/';
	echo $page;
	echo '.php"><div id="liuyan" align="center"><input type="text" name=topic placeholder="请输入标题" style="width:400px;height:35px;font-size:18px;vertical-align:middle ;float left;"/> ';
      echo '</div><p align="center"><font size="9px"> <textarea style="font-size:16px;" align="center" rows="17" name="message" cols="91"></textarea></font></p>';
	echo '<p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp';
      echo '<input size=10 type="submit"  style="text-align:center;margin:auto;width:60px;height:20px;font-size:15px;line-height:15px;" align="center"  onclick="refresh()" value="提交" name="B1">';
      echo '&nbsp&nbsp <input size=10 style="text-align:center;margin:auto;width:60px;height:20px;font-size:15px;line-height:15px;" align="center" type="reset" value="重置" name="B2"></form>';
      echo '</p>';
      $topic=@$_POST['topic'];
	$message=str_replace('
','<br/>',@$_POST['message']);
     echo '<script type="text/javascript">function refresh(){    windowl.location.href=window.location.href;}</script>';
	$result2=mysql_query("SELECT name FROM bbs WHERE message='$message' and name='$name';");
	$arr2=mysql_fetch_array($result2);
     if($message==""){
	}else if ($name==$arr2[0]){
      //   echo "<script>alert('您的留言重复了！或者不要重复提交。')</script>";
     }else{
         $sql4 = "INSERT INTO bbs (id, name, message, page, ip, time_at,topic) VALUES (NULL, '$name',  '$message', '$page', '$ip', NOW(), '$topic');";
         $result4=mysql_query($sql4);
         if ($result4)echo "留言成功！"; else echo "留言失败，可能服务器暂时不响应，请返回重试！";
         echo "<br/>您的留言如下：<br/><table><tr><td>";
         echo "<h2 align='center' style='color:red'>";
         echo $topic;
         echo "</h2>";
         echo $message;
         echo "</td></tr></table>";
     }

}else{
	echo "<font color='#A1A1A1'>登录后可以看见别人发言或进行留言。</font>";
}

echo '</blockquote></blockquote><br/><br/><br/><br/><br/><br/><br/></body></html>';
?>
